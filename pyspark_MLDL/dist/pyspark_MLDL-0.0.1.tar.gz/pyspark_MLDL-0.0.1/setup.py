from setuptools import setup

setup(
    name='pyspark_MLDL',
    version='0.0.1',
    packages=['ankus4pass_pyspark'],
    url='https://github.com/prismdata/Bigdata_ML_Library',
    license='',
    author='prismdata',
    author_email='prismdata@naver.com',
    description=''
)
