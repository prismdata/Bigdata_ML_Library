from setuptools import setup

setup(
    name='ankus4pass_DLib',
    version='0.0.1',
    packages=['ankus4passDALib', 'ankus4passDALib.example', 'ankus4passDALib.unsupervised'],
    url='',
    license='apache-2.0',
    author='prismdata',
    author_email='',
    description=''
)
